$(document).ready(function () {
    $('#btnsearch').click(function () {
        let getdata = $("#myInput").val();
        console.log(getdata);
        $.ajax({
            type: 'GET',
            dataType: 'json',
            url: 'http://api.weatherapi.com/v1/forecast.json?key=5fdbad7a97924bc9bf7102824201910&q=' + getdata+"&days=1",
            success: function (res) {
                console.log('successfully get data from json-server')
                let weather = []
                var x = false
                $.each(res, function () {
                    if (!x) {
                        weather +=
                            `  <div class="container"> 
                            <h4>Weather App</h4>                   
                          <p>Location: ${res.location.name}</p>
                         <p>Temperature:
                         <span id="tempc" style="cursor: pointer; display: ;"> ${res.current.temp_c}&#8451;</span> 
                       
                         <span id="tempf" style="cursor: pointer; display:none;"> ${res.current.temp_f}&#8457;</span>
                          
                         <span><img src="${res.current.condition.icon}"></img></span>
                         </p>                      
                        
                         <p>Humidity :${res.current.humidity}</p>
                          <p>Wind Speed :${res.current.wind_kph} km/h</p>
                          <p> Last Updated : ${res.current.last_updated.substring(11)}</p> 
                          <p>Lattitude: ${res.location.lat}</p>
                          <p>Longitude: ${res.location.lon}</p>  
                          <p>Max Temp: ${res.forecast.forecastday[0].day.maxtemp_c}</p> 
                          <p>Min Temp: ${res.forecast.forecastday[0].day.maxtemp_c}</p>                          
                      </div>`
                    }
                    x = true
                })
                $('.card').empty()
                $('.card').append(weather)
            }
        })
    })
    $( ".card" ).delegate( "#tempc", "click", function() {
    $('#tempc').click(function()
    {      
        $('#tempc').css('display','none')
        $('#tempf').css('display','')
    })
})
$( ".card" ).delegate( "#tempf", "click", function() {
    $('#tempf').click(function()
    {      
        $('#tempf').css('display','none')
        $('#tempc').css('display','')
    })
})

    $('#cl').click(function()
    {
        $.ajax({
            url: "https://geolocation-db.com/jsonp",
            jsonpCallback: "callback",
            dataType: "jsonp",
            success: function(location) {              
              $('#city').html(location.city)
              //console.log(city)
              $('#cl').hide()              
               $('#latitude').html(location.latitude);
              $('#longitude').html(location.longitude);
              $('#ip').html(location.IPv4); 
            }
          });
    })

    
    $('#btn2').click(function()
    {
        $.ajax({
            url: "https://geolocation-db.com/jsonp",
            jsonpCallback: "callback",
            dataType: "jsonp",
            success: function(location) {             
               console.log(location.latitude);               
               $('#lat').html(location.latitude);
              $('#lan').html(location.longitude);
              $('#ip').html(location.IPv4); 
            }
          });
    })


})
 

 