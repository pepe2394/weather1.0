$(document).ready(function () {
    $('#btnsearch').click(function () {
        let getdata = $("#myInput").val();
        console.log(getdata);
        $.ajax({
            type: 'GET',
            dataType: 'json',
            url: 'http://api.weatherapi.com/v1/current.json?key=5fdbad7a97924bc9bf7102824201910&q=' + getdata,
            success: function (res) {
                console.log('successfully get data from json-server')
                let weather = []
                var x = false
                $.each(res, function () {
                    if (!x) {                                            
                        
                        weather +=
                            `  <div class="container"> 
                            <h4>Weather App</h4>                   
                          <p>Location: ${res.location.name}</p>
                         <p><span id="tempc" style="cursor: pointer;">Temperature: ${res.current.temp_c} &#8451;</span> </p>
                         <button class=" btn "id="converter"> <span id="tempc" style="cursor: pointer;">Temperature: ${res.current.temp_c} &#8451;</span><span id="tempf" style="display:none"> ${res.current.temp_f} &#8457;</span></button>
                         <p> <span id="tempf" > ${res.current.temp_f} &#8457;</span></p>
                         <p> <img src="${res.current.condition.icon}"></img></p>                         
                          <p>Humidity :${res.current.humidity}</p>
                          <p>Wind Speed :${res.current.wind_kph} km/h</p>
                          <p> Last Updated : ${res.current.last_updated.substring(11)}</p>         
                          
                      </div>`
                    }
                    x = true
                })
                $('.card').empty()
                $('.card').append(weather)
            }
        })
    })

})

$(document).ready(function(){
    $('#cl').click(function()
    {
        $.ajax({
            url: "https://geolocation-db.com/jsonp",
            jsonpCallback: "callback",
            dataType: "jsonp",
            success: function(location) {              
              $('#city').html(location.city)
              //console.log(city)
              $('#cl').hide()
              
             /*  $('#latitude').html(location.latitude);
              $('#longitude').html(location.longitude);
              $('#ip').html(location.IPv4); */
            }
          });
    })     
})

$(document).ready(function(){
    $('#converter').click(function()
    {       
      
    })
})

    
    
    